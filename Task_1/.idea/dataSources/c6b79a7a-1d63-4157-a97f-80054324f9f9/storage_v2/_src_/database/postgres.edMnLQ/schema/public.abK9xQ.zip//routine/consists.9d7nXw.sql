create function consists(a text, b text) returns boolean
    language plpgsql
as
$$
begin
    return b like '%' || a || '%';
end;
$$;

alter function consists(text, text) owner to postgres;

